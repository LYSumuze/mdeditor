import fs from 'fs';

const src = fs.readFileSync('src/main.ts', 'utf-8');

// Find the emoji categories arrays
// They look like: { name: 'xxx', emojis: ['😀','😁',...] }
// We'll extract all single-quoted strings containing emoji characters

// Match all strings inside emojis arrays
const regex = /emojis:\s*\[(.*?)\]/gs;
const allEmoji = new Set();

let match;
while ((match = regex.exec(src)) !== null) {
  const content = match[1];
  // Extract single-quoted strings
  const strings = content.matchAll(/'([^']+)'/g);
  for (const s of strings) {
    const str = s[1];
    // Check if it contains emoji-range characters
    for (const ch of str) {
      const cp = ch.codePointAt(0);
      if (cp > 0x2000) {
        allEmoji.add(str);
        break;
      }
    }
  }
}

console.log(`Total unique emoji: ${allEmoji.size}`);

const cpList = [];
for (const emoji of allEmoji) {
  const codepoints = [...emoji]
    .filter(ch => ch !== '\uFE0F' && ch !== '\uFE0E')
    .map(ch => ch.codePointAt(0).toString(16))
    .join('-');
  cpList.push(codepoints);
  console.log(`${codepoints} | ${emoji}`);
}

// Save list for download script
fs.writeFileSync('_emoji_codepoints.json', JSON.stringify(cpList, null, 2));
console.log('\nSaved to _emoji_codepoints.json');
